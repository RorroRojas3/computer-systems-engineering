#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"

typedef struct contactInformation
{
    char name[MAXCHARACTERS];
    int phoneNumber;
    int key;
} *contactInfo;

contactInfo contactAllocation()
{
    contactInfo contact;
    contact = (contactInfo)calloc(1, sizeof(struct contactInformation));
    return contact;
}

void contactSetKey(contactInfo contact, int key)
{
    contact->key = key;
}

void freeContact(contactInfo contact)
{
    free(contact);
}

void contactPrint(contactInfo contact)
{
    printf("Name: %s\n", contact->name);
    printf("Phone number: %d\n\n", contact->phoneNumber);
}

void updateContact(contactInfo searchContact, contactInfo newContact)
{
    strcpy(searchContact->name, newContact->name);
    searchContact->phoneNumber = newContact->phoneNumber;
}

void menu(void)
{
     // Asks the user to enter a command and prints those commands
    printf("**********************************************\n");
    printf("Please enter any of these commands:\n");
    printf("Add - Adds contact to Table\n");
    printf("Delete - Deletes contact from Table\n");
    printf("Update - Updates contact information already stored in Table");
    printf("Lookup - Display contact information\n");
    printf("HELP - Prints menu\n");
    printf("QUIT - Exits Program\n");
    printf("**********************************************\n\n");
}

int contactCompare(contactInfo searchContact, contactInfo tableContact)
{
    if (searchContact->key == tableContact->key)
    {
        return 0;
    }
    else
    {
        return -1;
    }
};

contactInfo contactFill(contactInfo contact, int key)
{
    char input[MAXCHARACTERS];
    printf("Please enter the name you want to store in the Table: ");
    fgets(input, MAXCHARACTERS, stdin);
    sscanf(input, "%s", contact->name);
    printf("Please enter the person's phone number: ");
    fgets(input, MAXCHARACTERS, stdin);
    sscanf(input, "%d", &contact->phoneNumber);
    contact->key = key;
    return contact;
}