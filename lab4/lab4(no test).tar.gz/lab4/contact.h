#ifndef CONTACT_H
#define CONTACT_H

#define MAXCHARACTERS 1994

typedef struct contactInformation *contactInfo;

contactInfo contactAllocation();

void contactSetKey(contactInfo, int);

void freeContact(contactInfo);

void menu();

void updateContact(contactInfo, contactInfo);

void contactPrint(contactInfo);

int contactCompare(contactInfo, contactInfo);

contactInfo contactFill(contactInfo, int);

#endif // End of contact.h