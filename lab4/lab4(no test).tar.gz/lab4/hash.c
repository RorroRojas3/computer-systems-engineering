#include "hash.h"


int hashFunction(int tableSize, int key)
{
    return key % tableSize;
}