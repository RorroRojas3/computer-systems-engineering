#ifndef HASH_H
#define HASH_H

int hashFunction(int, int);

#endif // End of hash.h