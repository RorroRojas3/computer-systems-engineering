#include <stdio.h>
#include <stdlib.h>
#include "table.h"
#include "list.h"
#include "hash.h"
#include "contact.h"

/* define struct table int table.c */
typedef struct table 
{
    list_t *listArray;
    int tableSize;
} *table_t;

/* initialize the table */
table_t Table_new(int table_size) 
{
    table_t hashTable;
    int c1;
    hashTable = (table_t)calloc(1, sizeof(struct table));
    if (hashTable != NULL)
    {
        hashTable->tableSize = table_size;
        hashTable->listArray = (list_t *)calloc(table_size, sizeof(list_t));
        if (hashTable->listArray != NULL)
        {
            for (c1 = 0; c1 < table_size; c1++)
            {
                hashTable->listArray[c1] = list_init();
            }
        }
        else
        {
            free(hashTable);
            hashTable = NULL;
        }
    }
    return hashTable;
}

/* insert one item */
int Table_insert (table_t table, key_t key, data_t contact)
{
    contactInfo searchContact;
    int index;
    int insertResult;
    int comparisonResult;
    index = hashFunction(table->tableSize, key);
    contactSetKey(contact, key);
    searchContact = list_first(table->listArray[index]);
    if (searchContact == NULL)
    {
        contactFill(contact, key);
        insertResult = list_append(table->listArray[index], contact);
        if (insertResult == 0)
        {
            return 0;
        }
        else
        {
            return -1;
        }
    }
    else
    {
       while (searchContact != NULL)
       {
           comparisonResult = contactCompare(searchContact, contact);
           if (comparisonResult == 0)
           {
               return -1;
           }
           else
           {
               searchContact = list_next(table->listArray[index]);
           }
       }
    }
    contactFill(contact, key);
    insertResult = list_append(table->listArray[index], contact);
    if (insertResult == 0)
    {
         return 0;
    }
    else
    {
        return -1;
    }
}

/* find an item with key */
data_t Table_find (table_t table, key_t key)
{
    contactInfo temporaryContact;
    data_t searchContact;
    int index;
    index = hashFunction(table->tableSize, key);
    temporaryContact = contactAllocation();
    contactSetKey(temporaryContact, key);
    searchContact = list_find(table->listArray[index], temporaryContact, (cmpfunc)contactCompare);
    if (searchContact != NULL)
    {
        freeContact(temporaryContact);
        return searchContact;
    }
    else
    {
        freeContact(temporaryContact);
        return NULL;
    }
}

/* update item data in place */
int Table_update(table_t table, key_t key, data_t newContact)
{
    contactInfo searchContact;
    int index;
    int compareResult;
    contactSetKey(newContact, key);
    index = hashFunction(table->tableSize, key);
    searchContact = list_first(table->listArray[index]);
    while (searchContact != NULL)
    {
        compareResult = contactCompare(searchContact, newContact);
        if (compareResult == 0)
        {
            newContact = contactFill(newContact, key);
            updateContact(searchContact, newContact);
            return 0;
        }
        else
        {
            searchContact = list_next(table->listArray[index]);
        }
    }
    return -1;
}

/* remove one item */
data_t Table_remove (table_t table, key_t key)
{
    int removeResult;
    int index;
    contactInfo searchContact;
    index = hashFunction(table->tableSize, key);
    searchContact = Table_find(table, key);
    if (searchContact != NULL)
    {
        removeResult = list_remove(table->listArray[index]);
        if (removeResult == 0)
        {
            return searchContact;
        }
        else
        {
            return NULL;
        }
    }
    else
    {
        return NULL;
    }
}

/* free the entire table */
void Table_free (table_t *table)
{
    int c1;
    contactInfo temporaryContact;
    temporaryContact = list_first((*table)->listArray[0]);;
    if (temporaryContact != NULL)
    {
        for (c1 = 0; c1 < (*table)->tableSize; c1++)
        {
            temporaryContact = list_first((*table)->listArray[c1]);
            while (temporaryContact != NULL)
            {
                free(temporaryContact);
                temporaryContact = list_next((*table)->listArray[c1]);
            }
        }
    }
    for (c1 = 0; c1 < (*table)->tableSize; c1++)
    {

        list_finalize((*table)->listArray[c1]);
    }
    free((*table)->listArray);
    free(*table);
}