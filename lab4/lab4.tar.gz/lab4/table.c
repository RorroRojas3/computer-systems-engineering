#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "table.h"
#include "SingleLinkedList.h"

// Define struct table in table.c
typedef struct table 
{
    list_t list; 
} *table_t;

table_t Table_new(int table_size)
{
    int c1;
    table_t table;
    table = (table_t)calloc(1, sizeof(struct table));
    for (c1 = 0; c1 < table_size; c1++)
    {
        table[c1].list = list_init();
    }
    return table;
}

int Table_insert(table_t table, key_t index, data_t name)
{
    table[index].list = list_append(table[index].list, name);
    return 0;
}

data_t Table_find(table_t, key_t);

int Table_update(table_t, key_t, data_t);

data_t Table_remove(table_t, key_t);

void Table_free(table_t);

// Hash function
int HashFunction(char * name, int tableSize)
{
    int c1 = 0;
    int count = 0;
    int result = 0;
    for (c1 = 0; name[c1] != '\0'; c1++)
    {
        count++;
    }

    result = count % tableSize;
    return result;
}