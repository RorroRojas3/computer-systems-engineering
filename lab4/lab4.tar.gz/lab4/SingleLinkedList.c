// Name: Rodrigo Ignacio Rojas Garcia
// Course Number: ECE 2230 
// Section: 001
// Semester: Spring 2017
// Assignment Number: 4

// Library Declartion Section
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "SingleLinkedList.h"

typedef struct node
{
    struct node *next;
    data_t name;
} *node_t;

typedef struct list 
{
    node_t head;
    node_t tail;
    node_t current;
} *list_t;

/* create a new empty list */
list_t list_init()
{
    list_t list;
    list = (list_t)calloc(1, sizeof(struct list));
    list->head = NULL;
    list->current = NULL;
    list->tail = NULL;
    return list;
}

int list_append(list_t block, data_t name)
{
    // If no node has been created yet, this if statement will run and create the first node,
    // set the name passed into the node's data, and set set head, tail, and current, to point
    // to the new node created
    if (block->head == NULL)
    {
        node_t node;
        node = (node_t)calloc(1, sizeof(struct node));
        node->name = name;
        node->next = NULL;
        block->head = node;
        block->tail = node;
        block->current = node;
    }
    // If there is at least one node already on list, it will check for two cases
    else
    {
        // If there is only one item on the list, this will create the a new node, make the new node next
        // pointer equal to NULL, set pass name to node's name data, set the head's next to point to new node
        // as well as the this new node will become the new current and tail
        if (block->head->next == NULL)
        {   node_t node;
            node = (node_t)calloc(1, sizeof(struct node));
            node->name = name;
            node->next = NULL;
            block->head->next = node;
            block->current = node;
            block->tail = node;
        }
        // If there are more than two items on the list, this will create  new node, make the new node next
        // pointer equal to NULL, set passed name in function to node's name data, and set the current's next to
        // point to the new node as well as the new node will become the new current and tail 
        else
        {
            node_t node;
            node = (node_t)calloc(1, sizeof(struct node));
            node->name = name;
            node->next = NULL;
            block->current->next = node;
            block->current = node;
            block->tail = node;
        }
    }
    return 0;
}

data_t list_find(list_t block, data_t name)
{
    data_t temporaryName;
    temporaryName = list_first(block);
    while (temporaryName != NULL)
    {
        if (strcmp(temporaryName,name) == 0)
        {
            return temporaryName;
        }
        else
        {
            temporaryName = list_next(block);
        }
    }

    return NULL;
}

data_t list_first(list_t block)
{
    if (block->head != NULL)
    {   
        if (block->head->name != NULL)
        {
            block->current = block->head;
            return block->head->name;
        }
        else
        {
            return NULL;
        }
    }
    else
    {
        return NULL;
    }
}

data_t list_next(list_t block)
{
    if (block->current != NULL)
    {
        if (block->current->next != NULL)
        {
            if (block->current->next->name != NULL)
            {
                block->current = block->current->next;
                return block->current->name;
            }
            else
            {
                return NULL;
            }
        }
        else
        {
            return NULL;
        }
    }
    else
    {
        return NULL;
    }
}

int list_remove(list_t block)
{
    if (block->current != NULL)
    {
        if (block->current == block->head)
        {
            if (block->current->next != NULL)
            {
                block->head = block->current->next;
                free(block->current);
                block->current = block->head;
                return 0;
            }
            else
            {
                block->current->next= NULL;
                block->current->name = NULL;
                free(block->current);
                block->current = NULL;
                block->head = NULL;
                block->tail = NULL;
                return 0;
            }
        }
        
        else if (block->current == block->tail)
        {

            block->current = block->head;
            while (block->current->next != block->tail)
            {
                block->current = block->current->next;
            }
            block->tail->name = NULL;
            block->tail->next = NULL;
            free(block->tail);
            block->current->next = NULL;
            block->tail = block->current;
            return 0;
        }
        
        else
        {
            node_t temporaryCurrentNode;
            node_t temporaryNextNode;
            temporaryNextNode = block->current->next;
            temporaryCurrentNode = block->current;
            block->current = block->head;
            while (block->current->next != temporaryCurrentNode)
            {
                block->current = block->current->next;
            }
            block->current->next = temporaryNextNode;
            temporaryCurrentNode->next = NULL;
            temporaryCurrentNode->name = NULL;
            free(temporaryCurrentNode);
            return 0;
        }
    }
    
    return -1;
}

int list_finalize(list_t block)
{
    node_t current;
    node_t next;
    block->current = block->head;
    next = block->current;
    while (next != NULL)
    {
        current = next;
        next = block->current->next;
        free(current);
    }
    free(block);
    return 0;
}