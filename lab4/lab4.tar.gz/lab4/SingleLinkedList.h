// Name: Rodrigo Ignacio Rojas Garcia
// Course Number: ECE 2230 
// Section: 001
// Semester: Spring 2017
// Assignment Number: 4

#include "table.h"

#ifndef LIST_H
#define LIST_H

typedef struct list *list_t;

/* create a new empty list */
list_t list_init();

/* append to tail of list */
int list_append(list_t, data_t);

/* find and sets current item using callback compare function */
data_t list_find(list_t, data_t);

/* return item at head of list, set current item */
data_t list_first(list_t);

/* return next item after current item */
data_t list_next(list_t);

/* remove current item */
int list_remove(list_t);

/* free all resources allocated by the list */
int list_finalize(list_t);

#endif
