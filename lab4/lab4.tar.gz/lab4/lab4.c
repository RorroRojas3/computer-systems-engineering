#include <stdio.h>
#include <string.h>
#include "table.h"
/* 
*
*
*
*
*
*/


int main(int argc, char *argv[])
{
    int result;
    int tableSize;
    char *namePointer;
    char input[MAXCHARACTERS];
    char name[MAXCHARACTERS];
    printf("Please enter the Table Size desired: ");
    fgets(input, MAXCHARACTERS, stdin);
    sscanf(input, "%d", &tableSize);
    printf("Table Size: %d\n", tableSize);
    printf("Please enter your name: ");
    fgets(input, MAXCHARACTERS, stdin);
    sscanf(input, "%s", name);
    printf("%s\n", name);
    namePointer = name;
    result = HashFunction(namePointer, 8);
    printf("%d\n", result);
    

    
}