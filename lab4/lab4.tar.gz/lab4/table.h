// Name: Rodrigo Ignacio Rojas Garcia
// Course Number: ECE 2230 
// Section: 001
// Semester: Spring 2017
// Assignment Number: 4


#ifndef TABLE_H
#define TABLE_H

#define MAXCHARACTERS 1994

typedef void *data_t;

typedef int key_t;

// Define struct table in table.c
typedef struct table *table_t;

// Initialize the table
table_t Table_new(int table_size);

// Insert one item
int Table_insert(table_t, key_t, data_t);

// Find an item with key
data_t Table_find(table_t, key_t);

// Update item data in place
int Table_update(table_t, key_t, data_t);

// Remove one item
data_t Table_remove(table_t, key_t);

// Free the entire table
void Table_free(table_t);

// Hash function
int HashFunction(char *, int);


#endif /* End of TABLE_H */