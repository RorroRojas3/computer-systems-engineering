// Name: Rodrigo Ignacio Rojas Garcia
// Course Number: ECE 2230 
// Section: 001
// Semester: Spring 2017
// Assignment Number: 4

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "table.h"
#include "contact.h"

int main(int argc, char *argv[])
{
    // Variable Declaration Section
    char input[MAXCHARACTERS];
    char command[MAXCHARACTERS];
    int tableSize;
    int key;
    int functionResult;
    table_t table;

    menu();
    printf("Please enter size of the Table: ");
    fgets(input, MAXCHARACTERS, stdin);
    sscanf(input, "%d", &tableSize);
    table = Table_new(tableSize);

    while(1)
    {
        printf("\n> ");
        memset(input, '\0', sizeof(input));
        memset(command, '\0', sizeof(command));
        fgets(input, MAXCHARACTERS, stdin);
        sscanf(input, "%s", command);

        if (strcmp("Add", command) == 0)
        {
            contactInfo contact;
            printf("\nKey: ");
            fgets(input, MAXCHARACTERS, stdin);
            sscanf(input, "%d", &key);
            contact = contactAllocation();
            functionResult = Table_insert(table, key, contact);
            if (functionResult == 0)
            {
                printf("Contact has been stored in the Table.\n\n");
            }
            else
            {
                free(contact);
                printf("Contact could not be stored in the Table.\n\n");
            }
        }
        else if (strcmp("Delete", command) == 0)
        {
            contactInfo contact;
            printf("\nKey: ");
            fgets(input, MAXCHARACTERS, stdin);
            sscanf(input, "%d", &key);
            contact = Table_remove(table, key);
            if (contact != NULL)
            {
                free(contact);
                printf("Contact has been removed from the Table.\n\n");
            }
            else
            {
                printf("Contact does not exists on the Table.\n\n");
            }
            
        }
        else if (strcmp("Lookup", command) == 0)
        {
            contactInfo contact;
            printf("\nKey: ");
            fgets(input, MAXCHARACTERS, stdin);
            sscanf(input, "%d", &key);
            contact = Table_find(table, key);
            if (contact != NULL)
            {
                contactPrint(contact);
            }
            else
            {
                printf("Contact could not be found in Table.\n\n");
            }
        }
        else if (strcmp("Update", command) == 0)
        {
            contactInfo contact;
            printf("\nKey: ");
            fgets(input, MAXCHARACTERS, stdin);
            sscanf(input, "%d", &key);
            contact = contactAllocation();
            functionResult = Table_update(table, key, contact);
            if (functionResult == 0)
            {
                printf("Contact has been updated.\n\n");
            }
            else
            {
                free(contact);
                printf("Contact was not updated.\n\n");
            }
        }
        else if (strcmp("Help", command) == 0)
        {
            menu();
        }
        else if (strcmp("Quit", command) == 0)
        {
            Table_free(&table);
            exit(0);
        }
        else
        {
            printf("You have entered an invalid command.\n\n");
        }
        menu();
    }


}