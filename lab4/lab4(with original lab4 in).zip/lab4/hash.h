// Name: Rodrigo Ignacio Rojas Garcia
// Course Number: ECE 2230 
// Section: 001
// Semester: Spring 2017
// Assignment Number: 4

#ifndef HASH_H
#define HASH_H

// Defines function hasFunction with a returning type int
int hashFunction(int, int);

#endif // End of hash.h